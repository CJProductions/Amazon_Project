<?php

# user message
function user_message(){
    $message = "";
    if(isset($_SESSION["user_message"])) {
        $message = $_SESSION["user_message"];
        unset($_SESSION["user_message"]);
    }
    return $message;
}

# only user
function onlyuser($conn, $email){ // at registration check to make sure there none of the same
    $sql = "SELECT email FROM student WHERE email = ?"; // check if the inputted email is already in the emails
    $stmt = $conn->prepare($sql); // prepare sql
    $stmt->bindParam(1, $email);
    $stmt->execute(); //run sql
    $result = $stmt->fetch(PDO::FETCH_ASSOC); // bring results
    if ($result) { // if user is returned
        return false; // return false so y
    } else {
        return true;
    }

}

# user reg
function reg_user($conn){
    // prepare sql
    $sql = "INSERT INTO student (school_id, fname, sname, email, password, pathway, year) VALUES(?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);

    // list and bind all paramiters for security
    $stmt->bindParam(1, $_POST["school_id"]);
    $stmt->bindParam(2, $_POST["fname"]);
    $stmt->bindParam(3, $_POST["sname"]);
    $stmt->bindParam(4, $_POST["email"]);
    $stmt->bindParam(5, password_hash($_POST["password"], PASSWORD_DEFAULT)); // use a hashing algorithm to encrypt the password
    $stmt->bindParam(6, $_POST["pathway"]);
    $stmt->bindParam(7, $_POST["year"]);


    $stmt->execute(); // run the query
    $conn = null; // closes the connection so can't be abused
    return true; // register successful
}

# user login
function login($conn, $email){
    $sql = "SELECT student_id, password FROM student WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(1, $email);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $conn = null;

    if ($result) {
        return $result;
    } else {
        return false;
    }
}

#get user id
function getuserid($conn, $email){
    $sql = "SELECT student_id FROM student WHERE email = ?"; // get only one student_id since there's unique emails (meaning only one can exist)
    $stmt = $conn->prepare($sql); // prepare
    $stmt->bind_param(1, $email); // bind the param for security
    $stmt->execute(); // run sql
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result["student_id"];
}

function reg_school($conn){

    // Prepare and execute the SQL query
    $sql = "INSERT INTO school (school_name, school_email, school_phone) VALUES (?, ?, ?)";  //prepare the sql to be sent

    $stmt = $conn->prepare($sql); //prepare to sql

    $stmt->bindParam(1, $_POST['sname']);  //bind parameters for security
    $stmt->bindParam(2, $_POST['email']);
    $stmt->bindParam(3, $_POST['phone']);


    $stmt->execute();  //run the query to insert
    $conn = null;  // closes the connection so cant be abused.
    return true; // Registration successful
}

function school_getter($conn){
    // function to get all the schools for a drop down

    $sql = "SELECT school_id, school_name FROM school";
    //get all schools in system
    $stmt = $conn->prepare($sql);

    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $conn = null;
    return $result;
}